import { Calendar, Users, Award, BookOpen, Image, MessageSquare } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Link } from "react-router-dom";
import Hero from "@/components/Hero";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

const Index = () => {
  const features = [
    {
      icon: Users,
      title: "Strong Community",
      description: "Join over 500 active members in a vibrant cultural community.",
      link: "/membership"
    },
    {
      icon: Calendar,
      title: "Rich Events",
      description: "Participate in cultural celebrations, workshops, and networking events.",
      link: "/events"
    },
    {
      icon: Award,
      title: "Academic Excellence",
      description: "Access mentorship, study groups, and academic achievement recognition.",
      link: "/about"
    },
    {
      icon: BookOpen,
      title: "Cultural Heritage",
      description: "Preserve and celebrate Kamba traditions and customs.",
      link: "/about"
    }
  ];

  const upcomingEvents = [
    {
      title: "Cultural Week 2024",
      date: "March 15-22",
      description: "Week-long celebration of Kamba culture with dances, music, and food."
    },
    {
      title: "Leadership Training",
      date: "April 5",
      description: "Professional development workshop for current and aspiring leaders."
    },
    {
      title: "Community Outreach",
      date: "April 20",
      description: "Service project supporting local schools in Kitui County."
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <Hero />
      
      {/* Features Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-bold text-primary mb-6">
              Why Join Kamba Nation?
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Experience the perfect blend of cultural pride and academic excellence 
              in a supportive community that feels like home.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="text-center hover:shadow-lg transition-smooth group">
                <CardHeader>
                  <feature.icon className="w-12 h-12 text-primary mx-auto mb-4 group-hover:scale-110 transition-transform" />
                  <CardTitle className="text-xl">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground mb-4">{feature.description}</p>
                  <Link to={feature.link}>
                    <Button variant="outline" size="sm">
                      Learn More
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Upcoming Events */}
      <section className="py-20 bg-muted">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-bold text-primary mb-6">
              Upcoming Events
            </h2>
            <p className="text-xl text-muted-foreground">
              Don't miss out on these exciting opportunities to connect and grow.
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {upcomingEvents.map((event, index) => (
              <Card key={index} className="hover:shadow-lg transition-smooth">
                <CardHeader>
                  <div className="flex items-center gap-2 text-accent font-semibold mb-2">
                    <Calendar className="w-4 h-4" />
                    {event.date}
                  </div>
                  <CardTitle className="text-lg">{event.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground mb-4">{event.description}</p>
                  <Button variant="outline" size="sm">
                    Learn More
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
          
          <div className="text-center mt-12">
            <Link to="/events">
              <Button variant="hero" size="lg">
                View All Events
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Quick Actions */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <Card className="text-center bg-gradient-to-br from-primary to-secondary text-primary-foreground">
              <CardContent className="p-8">
                <Image className="w-12 h-12 mx-auto mb-4" />
                <h3 className="text-xl font-bold mb-4">Explore Gallery</h3>
                <p className="mb-6 opacity-90">
                  Browse photos and videos from our cultural events and activities.
                </p>
                <Link to="/gallery">
                  <Button variant="cultural" className="bg-primary-foreground text-primary hover:bg-primary-foreground/90">
                    View Gallery
                  </Button>
                </Link>
              </CardContent>
            </Card>

            <Card className="text-center bg-gradient-to-br from-secondary to-accent text-secondary-foreground">
              <CardContent className="p-8">
                <Users className="w-12 h-12 mx-auto mb-4" />
                <h3 className="text-xl font-bold mb-4">Join Our Community</h3>
                <p className="mb-6 opacity-90">
                  Become a member and be part of our vibrant cultural family.
                </p>
                <Link to="/membership">
                  <Button variant="cultural" className="bg-secondary-foreground text-secondary hover:bg-secondary-foreground/90">
                    Register Now
                  </Button>
                </Link>
              </CardContent>
            </Card>

            <Card className="text-center bg-gradient-to-br from-accent to-primary text-accent-foreground">
              <CardContent className="p-8">
                <MessageSquare className="w-12 h-12 mx-auto mb-4" />
                <h3 className="text-xl font-bold mb-4">Get In Touch</h3>
                <p className="mb-6 opacity-90">
                  Have questions? We're here to help and guide you.
                </p>
                <Link to="/contact">
                  <Button variant="cultural" className="bg-accent-foreground text-accent hover:bg-accent-foreground/90">
                    Contact Us
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Index;
