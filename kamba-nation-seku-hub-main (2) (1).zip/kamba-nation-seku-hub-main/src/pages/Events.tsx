import { Calendar, MapPin, Clock, Users, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

const Events = () => {
  const upcomingEvents = [
    {
      id: 1,
      title: "Cultural Week 2024",
      date: "March 15-22, 2024",
      time: "Various Times",
      location: "SEKU Main Campus",
      description: "A week-long celebration of Kamba culture featuring traditional dances, music, poetry, and cuisine.",
      category: "Cultural",
      attendees: 300,
      featured: true
    },
    {
      id: 2,
      title: "Academic Excellence Awards",
      date: "April 10, 2024", 
      time: "6:00 PM",
      location: "University Auditorium",
      description: "Annual ceremony recognizing outstanding academic achievements among our members.",
      category: "Academic",
      attendees: 150,
      featured: false
    },
    {
      id: 3,
      title: "Community Outreach - Kitui",
      date: "April 25, 2024",
      time: "8:00 AM",
      location: "Kitui County",
      description: "Community service trip to support local schools and distribute educational materials.",
      category: "Service",
      attendees: 50,
      featured: false
    }
  ];

  const pastEvents = [
    {
      title: "New Year Cultural Celebration",
      date: "January 20, 2024",
      attendees: 250,
      images: 15
    },
    {
      title: "Leadership Training Workshop",
      date: "February 14, 2024", 
      attendees: 80,
      images: 12
    },
    {
      title: "Career Mentorship Session",
      date: "February 28, 2024",
      attendees: 120,
      images: 8
    }
  ];

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "Cultural": return "bg-primary text-primary-foreground";
      case "Academic": return "bg-secondary text-secondary-foreground";
      case "Service": return "bg-accent text-accent-foreground";
      default: return "bg-muted text-muted-foreground";
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="cultural-pattern py-20">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-primary mb-6">
            Events & Activities
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Join us for exciting cultural celebrations, academic workshops, 
            community service, and networking opportunities throughout the year.
          </p>
        </div>
      </section>

      {/* Upcoming Events */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center text-primary mb-12">
            Upcoming Events
          </h2>
          <div className="grid lg:grid-cols-2 xl:grid-cols-3 gap-8">
            {upcomingEvents.map((event) => (
              <Card key={event.id} className={`relative hover:shadow-lg transition-smooth ${event.featured ? 'ring-2 ring-accent' : ''}`}>
                {event.featured && (
                  <div className="absolute -top-2 -right-2 bg-accent text-accent-foreground rounded-full p-2">
                    <Star className="w-4 h-4" />
                  </div>
                )}
                <CardHeader>
                  <div className="flex items-start justify-between mb-2">
                    <Badge className={getCategoryColor(event.category)}>
                      {event.category}
                    </Badge>
                    {event.featured && (
                      <Badge variant="outline" className="text-accent border-accent">
                        Featured
                      </Badge>
                    )}
                  </div>
                  <CardTitle className="text-xl">{event.title}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-muted-foreground">{event.description}</p>
                  
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Calendar className="w-4 h-4" />
                      <span>{event.date}</span>
                    </div>
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Clock className="w-4 h-4" />
                      <span>{event.time}</span>
                    </div>
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <MapPin className="w-4 h-4" />
                      <span>{event.location}</span>
                    </div>
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Users className="w-4 h-4" />
                      <span>{event.attendees} expected attendees</span>
                    </div>
                  </div>

                  <div className="pt-4">
                    <Button variant={event.featured ? "hero" : "default"} className="w-full">
                      Register for Event
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Event Calendar */}
      <section className="py-16 bg-muted">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center text-primary mb-12">
            Event Calendar
          </h2>
          <Card className="max-w-4xl mx-auto">
            <CardHeader className="text-center">
              <CardTitle className="flex items-center justify-center gap-2">
                <Calendar className="w-6 h-6" />
                March 2024
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8">
                <Calendar className="w-24 h-24 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground mb-4">
                  Interactive calendar coming soon! 
                </p>
                <p className="text-sm text-muted-foreground">
                  Full calendar functionality will be available with backend integration.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Past Events */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center text-primary mb-12">
            Recent Events
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {pastEvents.map((event, index) => (
              <Card key={index} className="hover:shadow-lg transition-smooth">
                <CardHeader>
                  <CardTitle className="text-lg">{event.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm text-muted-foreground">
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4" />
                      <span>{event.date}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Users className="w-4 h-4" />
                      <span>{event.attendees} attendees</span>
                    </div>
                  </div>
                  <Button variant="outline" className="w-full mt-4">
                    View Gallery ({event.images} photos)
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-primary text-primary-foreground">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Don't Miss Out!
          </h2>
          <p className="text-xl mb-8 opacity-90 max-w-2xl mx-auto">
            Stay updated with all our upcoming events and activities. 
            Join our community to receive exclusive invitations and early access to registration.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button variant="cultural" size="lg" className="text-lg px-8 py-6">
              Join Our Community
            </Button>
            <Button variant="outline" size="lg" className="text-lg px-8 py-6 bg-primary-foreground/10 border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground hover:text-primary">
              Subscribe to Updates
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Events;