import { useState } from "react";
import { Image, Play, Calendar, Users, Filter } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

const Gallery = () => {
  const [activeFilter, setActiveFilter] = useState("all");

  const mediaItems = [
    {
      id: 1,
      type: "image",
      title: "Kamba Nation Official Logo",
      event: "Official Branding",
      date: "2024",
      category: "cultural",
      thumbnail: "/lovable-uploads/6ba743f0-5e76-4992-b2ec-44399323b322.png"
    },
    {
      id: 2,
      type: "image",
      title: "Cultural Week 2023 - Traditional Dance",
      event: "Cultural Week 2023",
      date: "March 2023",
      category: "cultural",
      thumbnail: "https://images.unsplash.com/photo-1577563908411-5077b6dc7624?w=400&h=300&fit=crop"
    },
    {
      id: 3,
      type: "video",
      title: "Leadership Training Workshop",
      event: "Leadership Training",
      date: "February 2024",
      category: "academic",
      thumbnail: "https://images.unsplash.com/photo-1552664730-d307ca884978?w=400&h=300&fit=crop"
    },
    {
      id: 4,
      type: "image",
      title: "Community Outreach - School Visit",
      event: "Community Service",
      date: "January 2024",
      category: "service",
      thumbnail: "https://images.unsplash.com/photo-1559027615-cd4628902d4a?w=400&h=300&fit=crop"
    },
    {
      id: 5,
      type: "image",
      title: "Annual Graduation Dinner",
      event: "Graduation Ceremony",
      date: "December 2023",
      category: "social",
      thumbnail: "https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=400&h=300&fit=crop"
    },
    {
      id: 6,
      type: "video",
      title: "Traditional Music Performance",
      event: "Cultural Week 2023",
      date: "March 2023",
      category: "cultural",
      thumbnail: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=400&h=300&fit=crop"
    },
    {
      id: 7,
      type: "image",
      title: "Academic Excellence Awards",
      event: "Awards Ceremony",
      date: "November 2023",
      category: "academic",
      thumbnail: "https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?w=400&h=300&fit=crop"
    }
  ];

  const filters = [
    { key: "all", label: "All Media", count: mediaItems.length },
    { key: "cultural", label: "Cultural Events", count: mediaItems.filter(item => item.category === "cultural").length },
    { key: "academic", label: "Academic", count: mediaItems.filter(item => item.category === "academic").length },
    { key: "service", label: "Community Service", count: mediaItems.filter(item => item.category === "service").length },
    { key: "social", label: "Social Events", count: mediaItems.filter(item => item.category === "social").length }
  ];

  const filteredItems = activeFilter === "all" 
    ? mediaItems 
    : mediaItems.filter(item => item.category === activeFilter);

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "cultural": return "bg-primary text-primary-foreground";
      case "academic": return "bg-secondary text-secondary-foreground";
      case "service": return "bg-accent text-accent-foreground";
      case "social": return "bg-muted text-muted-foreground";
      default: return "bg-muted text-muted-foreground";
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="cultural-pattern py-20">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-primary mb-6">
            Photo & Video Gallery
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Explore moments from our cultural celebrations, academic achievements, 
            community service projects, and memorable gatherings.
          </p>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-muted">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-4xl font-bold text-primary mb-2">500+</div>
              <div className="text-muted-foreground">Photos</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-secondary mb-2">50+</div>
              <div className="text-muted-foreground">Videos</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-accent mb-2">25+</div>
              <div className="text-muted-foreground">Events Covered</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-primary mb-2">3</div>
              <div className="text-muted-foreground">Years of Memories</div>
            </div>
          </div>
        </div>
      </section>

      {/* Filter Section */}
      <section className="py-8 border-b">
        <div className="container mx-auto px-4">
          <div className="flex items-center gap-4 mb-6">
            <Filter className="w-5 h-5 text-muted-foreground" />
            <span className="font-medium">Filter by category:</span>
          </div>
          <div className="flex flex-wrap gap-2">
            {filters.map((filter) => (
              <Button
                key={filter.key}
                variant={activeFilter === filter.key ? "default" : "outline"}
                size="sm"
                onClick={() => setActiveFilter(filter.key)}
                className="transition-smooth"
              >
                {filter.label} ({filter.count})
              </Button>
            ))}
          </div>
        </div>
      </section>

      {/* Gallery Grid */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredItems.map((item) => (
              <Card key={item.id} className="group overflow-hidden hover:shadow-lg transition-smooth cursor-pointer">
                <div className="relative aspect-[4/3] overflow-hidden">
                  <img
                    src={item.thumbnail}
                    alt={item.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  {item.type === "video" && (
                    <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                      <div className="w-16 h-16 bg-primary text-primary-foreground rounded-full flex items-center justify-center">
                        <Play className="w-6 h-6 ml-1" />
                      </div>
                    </div>
                  )}
                  <div className="absolute top-2 left-2">
                    <Badge className={getCategoryColor(item.category)}>
                      {item.category}
                    </Badge>
                  </div>
                  <div className="absolute top-2 right-2">
                    <div className="bg-black/50 rounded-full p-1">
                      {item.type === "video" ? (
                        <Play className="w-4 h-4 text-white" />
                      ) : (
                        <Image className="w-4 h-4 text-white" />
                      )}
                    </div>
                  </div>
                </div>
                <CardContent className="p-4">
                  <h3 className="font-semibold mb-2 group-hover:text-primary transition-colors">
                    {item.title}
                  </h3>
                  <div className="space-y-1 text-sm text-muted-foreground">
                    <div className="flex items-center gap-2">
                      <Users className="w-4 h-4" />
                      <span>{item.event}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4" />
                      <span>{item.date}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {filteredItems.length === 0 && (
            <div className="text-center py-16">
              <Image className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">No media found</h3>
              <p className="text-muted-foreground">Try selecting a different category filter.</p>
            </div>
          )}
        </div>
      </section>

      {/* Recent Highlights */}
      <section className="py-16 bg-muted">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center text-primary mb-12">
            Recent Highlights
          </h2>
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="overflow-hidden">
              <div className="aspect-video bg-gradient-to-br from-primary to-secondary flex items-center justify-center">
                <Play className="w-12 h-12 text-primary-foreground" />
              </div>
              <CardContent className="p-6">
                <h3 className="font-semibold mb-2">Cultural Week 2024 Recap</h3>
                <p className="text-muted-foreground text-sm mb-4">
                  Watch highlights from our most recent cultural celebration.
                </p>
                <Button variant="outline" size="sm">
                  Watch Video
                </Button>
              </CardContent>
            </Card>

            <Card className="overflow-hidden">
              <div className="aspect-video bg-gradient-to-br from-secondary to-accent flex items-center justify-center">
                <Image className="w-12 h-12 text-secondary-foreground" />
              </div>
              <CardContent className="p-6">
                <h3 className="font-semibold mb-2">Leadership Training Photos</h3>
                <p className="text-muted-foreground text-sm mb-4">
                  Browse photos from our recent leadership development workshop.
                </p>
                <Button variant="outline" size="sm">
                  View Album
                </Button>
              </CardContent>
            </Card>

            <Card className="overflow-hidden">
              <div className="aspect-video bg-gradient-to-br from-accent to-primary flex items-center justify-center">
                <Users className="w-12 h-12 text-accent-foreground" />
              </div>
              <CardContent className="p-6">
                <h3 className="font-semibold mb-2">Community Service Gallery</h3>
                <p className="text-muted-foreground text-sm mb-4">
                  See our impact in the community through service projects.
                </p>
                <Button variant="outline" size="sm">
                  Explore Gallery
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-primary mb-6">
            Share Your Moments
          </h2>
          <p className="text-muted-foreground mb-8 max-w-2xl mx-auto">
            Have photos or videos from our events? We'd love to feature them in our gallery! 
            Contact us to share your content with the community.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button variant="hero" size="lg">
              Submit Content
            </Button>
            <Button variant="outline" size="lg">
              Contact Us
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Gallery;