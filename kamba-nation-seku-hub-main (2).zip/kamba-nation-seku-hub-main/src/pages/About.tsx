import { BookOpen, Target, Eye, Users, Award } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const About = () => {
  const leaders = [
    { name: "John Musyoka", role: "Chairperson", course: "Computer Science" },
    { name: "Grace Mwende", role: "Vice Chairperson", course: "Business Administration" },
    { name: "Peter Kioko", role: "Secretary General", course: "Engineering" },
    { name: "Faith Nduku", role: "Treasurer", course: "Education" },
    { name: "David Muema", role: "Organizing Secretary", course: "Agriculture" },
    { name: "Mary Syombua", role: "Assistant Secretary", course: "Nursing" },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="cultural-pattern py-20">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-primary mb-6">
            About Kamba Nation
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Discover our rich history, mission, and the passionate community that 
            makes Kamba Nation - SEKU Chapter a beacon of cultural excellence and academic achievement.
          </p>
        </div>
      </section>

      {/* Mission, Vision, Goals */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="text-center">
              <CardHeader>
                <Target className="w-12 h-12 text-primary mx-auto mb-4" />
                <CardTitle className="text-primary">Our Mission</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  To unite Kamba students at SEKU, promote our rich cultural heritage, 
                  foster academic excellence, and create lasting bonds that extend beyond university life.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardHeader>
                <Eye className="w-12 h-12 text-secondary mx-auto mb-4" />
                <CardTitle className="text-secondary">Our Vision</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  To be the premier student cultural association that preserves Kamba traditions 
                  while empowering members to excel academically and professionally.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardHeader>
                <Award className="w-12 h-12 text-accent mx-auto mb-4" />
                <CardTitle className="text-accent">Our Goals</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Cultural preservation, academic support, community service, 
                  professional networking, and creating a home away from home for all Kamba students.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* History Section */}
      <section className="py-16 bg-muted">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-bold text-center text-primary mb-12">
              Our Rich History
            </h2>
            <div className="prose prose-lg max-w-none">
              <p className="text-muted-foreground mb-6">
                Founded in 2014, Kamba Nation - SEKU Chapter emerged from a shared vision among 
                Kamba students to create a unifying platform that celebrates our cultural identity 
                while pursuing academic excellence. What began as informal gatherings has evolved 
                into one of the most vibrant cultural associations at South Eastern Kenya University.
              </p>
              <p className="text-muted-foreground mb-6">
                Over the years, we have organized numerous cultural festivals, academic support 
                programs, community outreach initiatives, and professional development workshops. 
                Our association has been instrumental in preserving Kamba traditions, language, 
                and customs among the younger generation.
              </p>
              <p className="text-muted-foreground">
                Today, we proudly serve over 500 active members across all faculties, making us 
                one of the largest and most influential student organizations at SEKU. Our alumni 
                network spans various industries, creating valuable mentorship and career opportunities 
                for current members.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Leadership Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center text-primary mb-12">
            Our Leadership Team
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
            {leaders.map((leader, index) => (
              <Card key={index} className="text-center hover:shadow-lg transition-smooth">
                <CardHeader>
                  <div className="w-20 h-20 bg-gradient-to-br from-primary to-secondary rounded-full mx-auto mb-4 flex items-center justify-center">
                    <Users className="w-8 h-8 text-primary-foreground" />
                  </div>
                  <CardTitle className="text-lg">{leader.name}</CardTitle>
                  <p className="text-primary font-medium">{leader.role}</p>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">{leader.course}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Constitution Section */}
      <section className="py-16 bg-muted">
        <div className="container mx-auto px-4 text-center">
          <div className="max-w-2xl mx-auto">
            <BookOpen className="w-16 h-16 text-primary mx-auto mb-6" />
            <h2 className="text-3xl md:text-4xl font-bold text-primary mb-6">
              Our Constitution
            </h2>
            <p className="text-muted-foreground mb-8">
              Our constitution outlines our values, governance structure, and operational 
              guidelines. It serves as the foundation for all our activities and decision-making processes.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button variant="default" size="lg">
                View Constitution Online
              </Button>
              <Button variant="outline" size="lg">
                Download PDF
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;