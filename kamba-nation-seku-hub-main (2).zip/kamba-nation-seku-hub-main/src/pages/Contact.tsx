import { MapPin, Phone, Mail, MessageSquare, Facebook, Instagram, Twitter } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";

const Contact = () => {
  const contactInfo = [
    {
      icon: MapPin,
      title: "Location",
      details: ["South Eastern Kenya University", "Kitui Campus", "P.O Box 170-90200, Kitui"]
    },
    {
      icon: Phone,
      title: "Phone",
      details: ["+254 700 123 456", "+254 711 987 654"]
    },
    {
      icon: Mail,
      title: "Email",
      details: ["info@kambanation-seku.org", "secretary@kambanation-seku.org"]
    }
  ];

  const socialMedia = [
    {
      name: "Facebook",
      icon: Facebook,
      link: "#",
      handle: "@KambaNationSEKU"
    },
    {
      name: "Instagram", 
      icon: Instagram,
      link: "#",
      handle: "@kambanation_seku"
    },
    {
      name: "Twitter",
      icon: Twitter,
      link: "#",
      handle: "@KambaNationSEKU"
    },
    {
      name: "WhatsApp",
      icon: MessageSquare,
      link: "#",
      handle: "Join our group"
    }
  ];

  const leadership = [
    {
      name: "John Musyoka",
      role: "Chairperson",
      email: "chair@kambanation-seku.org",
      phone: "+254 700 111 222"
    },
    {
      name: "Grace Mwende",
      role: "Vice Chairperson", 
      email: "vice@kambanation-seku.org",
      phone: "+254 700 333 444"
    },
    {
      name: "Peter Kioko",
      role: "Secretary General",
      email: "secretary@kambanation-seku.org",
      phone: "+254 700 555 666"
    },
    {
      name: "Faith Nduku",
      role: "Treasurer",
      email: "treasurer@kambanation-seku.org",
      phone: "+254 700 777 888"
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="cultural-pattern py-20">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-primary mb-6">
            Get In Touch
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Have questions, suggestions, or want to get involved? 
            We'd love to hear from you. Reach out through any of the channels below.
          </p>
        </div>
      </section>

      {/* Contact Information */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8">
            {contactInfo.map((info, index) => (
              <Card key={index} className="text-center hover:shadow-lg transition-smooth">
                <CardHeader>
                  <info.icon className="w-12 h-12 text-primary mx-auto mb-4" />
                  <CardTitle className="text-primary">{info.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  {info.details.map((detail, idx) => (
                    <p key={idx} className="text-muted-foreground mb-1">
                      {detail}
                    </p>
                  ))}
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Form */}
      <section className="py-16 bg-muted">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold text-primary mb-4">
                Send Us a Message
              </h2>
              <p className="text-muted-foreground">
                Fill out the form below and we'll get back to you as soon as possible.
              </p>
            </div>

            <Card>
              <CardContent className="p-8">
                <form className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="firstName">First Name</Label>
                      <Input id="firstName" placeholder="Enter your first name" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="lastName">Last Name</Label>
                      <Input id="lastName" placeholder="Enter your last name" />
                    </div>
                  </div>
                  
                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="email">Email Address</Label>
                      <Input id="email" type="email" placeholder="your.email@example.com" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="phone">Phone Number</Label>
                      <Input id="phone" placeholder="+254 700 000 000" />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="subject">Subject</Label>
                    <Input id="subject" placeholder="What is this message about?" />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="message">Message</Label>
                    <Textarea 
                      id="message" 
                      placeholder="Type your message here..." 
                      className="min-h-[120px]"
                    />
                  </div>

                  <Button variant="hero" size="lg" className="w-full md:w-auto">
                    Send Message
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Social Media */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-primary mb-4">
              Follow Us on Social Media
            </h2>
            <p className="text-muted-foreground">
              Stay connected and get the latest updates on our activities and events.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-4xl mx-auto">
            {socialMedia.map((social, index) => (
              <Card key={index} className="text-center hover:shadow-lg transition-smooth cursor-pointer group">
                <CardContent className="p-6">
                  <social.icon className="w-12 h-12 text-primary mx-auto mb-4 group-hover:scale-110 transition-transform" />
                  <h3 className="font-semibold mb-2">{social.name}</h3>
                  <p className="text-muted-foreground text-sm">{social.handle}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Leadership Contacts */}
      <section className="py-16 bg-muted">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-primary mb-4">
              Leadership Contacts
            </h2>
            <p className="text-muted-foreground">
              Reach out directly to our leadership team for specific inquiries.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {leadership.map((leader, index) => (
              <Card key={index} className="text-center">
                <CardHeader>
                  <div className="w-16 h-16 bg-gradient-to-br from-primary to-secondary rounded-full mx-auto mb-4 flex items-center justify-center">
                    <span className="text-primary-foreground font-bold text-lg">
                      {leader.name.split(' ').map(n => n[0]).join('')}
                    </span>
                  </div>
                  <CardTitle className="text-lg">{leader.name}</CardTitle>
                  <p className="text-primary font-medium">{leader.role}</p>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm text-muted-foreground">
                    <div className="flex items-center justify-center gap-2">
                      <Mail className="w-4 h-4" />
                      <span className="truncate">{leader.email}</span>
                    </div>
                    <div className="flex items-center justify-center gap-2">
                      <Phone className="w-4 h-4" />
                      <span>{leader.phone}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Office Hours */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <Card className="max-w-2xl mx-auto">
            <CardHeader className="text-center">
              <CardTitle className="text-2xl text-primary">Office Hours</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between items-center py-2 border-b">
                  <span className="font-medium">Monday - Friday</span>
                  <span className="text-muted-foreground">2:00 PM - 6:00 PM</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b">
                  <span className="font-medium">Saturday</span>
                  <span className="text-muted-foreground">10:00 AM - 2:00 PM</span>
                </div>
                <div className="flex justify-between items-center py-2">
                  <span className="font-medium">Sunday</span>
                  <span className="text-muted-foreground">Closed</span>
                </div>
              </div>
              <div className="mt-6 p-4 bg-accent/10 rounded-lg">
                <p className="text-sm text-muted-foreground text-center">
                  <strong>Note:</strong> Office hours may vary during exam periods and holidays. 
                  Please call ahead to confirm availability.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  );
};

export default Contact;