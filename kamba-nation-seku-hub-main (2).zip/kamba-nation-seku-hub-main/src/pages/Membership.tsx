import { Users, CreditCard, Shield, UserCheck, FileText, Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

const Membership = () => {
  const benefits = [
    "Access to cultural events and workshops",
    "Academic support and mentorship programs", 
    "Professional networking opportunities",
    "Leadership development training",
    "Community service participation",
    "Access to member-only resources and library",
    "Voting rights in elections",
    "Discounted rates for events and trips"
  ];

  const requirements = [
    "Must be a currently enrolled SEKU student",
    "Of Kamba ethnic background or strong cultural interest",
    "Commitment to association values and constitution",
    "Payment of registration and annual fees",
    "Active participation in at least 3 events per semester"
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="cultural-pattern py-20">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-primary mb-6">
            Join Our Community
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto mb-8">
            Become part of a vibrant community that celebrates culture, promotes excellence, 
            and creates lifelong connections at SEKU.
          </p>
          <Button variant="hero" size="lg" className="text-lg px-8 py-6">
            Register Now
          </Button>
        </div>
      </section>

      {/* Membership Fees */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center text-primary mb-12">
            Membership Fees
          </h2>
          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <Card className="relative overflow-hidden">
              <div className="absolute top-0 right-0 bg-accent text-accent-foreground px-4 py-1 text-sm font-medium">
                New Member
              </div>
              <CardHeader className="text-center">
                <CreditCard className="w-12 h-12 text-primary mx-auto mb-4" />
                <CardTitle className="text-2xl">Registration Fee</CardTitle>
                <div className="text-4xl font-bold text-primary">KSh 100</div>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground text-center mb-6">
                  One-time registration fee for new members. Includes welcome package 
                  and membership certificate.
                </p>
                <Button variant="default" className="w-full">
                  Pay Registration Fee
                </Button>
              </CardContent>
            </Card>

            <Card className="relative overflow-hidden">
              <div className="absolute top-0 right-0 bg-secondary text-secondary-foreground px-4 py-1 text-sm font-medium">
                Existing Member
              </div>
              <CardHeader className="text-center">
                <Calendar className="w-12 h-12 text-secondary mx-auto mb-4" />
                <CardTitle className="text-2xl">Renewal Fee</CardTitle>
                <div className="text-4xl font-bold text-secondary">KSh 50</div>
                <p className="text-sm text-muted-foreground">per semester</p>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground text-center mb-6">
                  Semester renewal fee to maintain active membership status 
                  and access to all benefits.
                </p>
                <Button variant="secondary" className="w-full">
                  Renew Membership
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Payment Process */}
      <section className="py-16 bg-muted">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center text-primary mb-12">
            Easy Payment Process
          </h2>
          <div className="max-w-4xl mx-auto">
            <div className="grid md:grid-cols-3 gap-8">
              <div className="text-center">
                <div className="w-16 h-16 bg-primary text-primary-foreground rounded-full flex items-center justify-center mx-auto mb-4 text-2xl font-bold">
                  1
                </div>
                <h3 className="text-xl font-semibold mb-2">Fill Registration Form</h3>
                <p className="text-muted-foreground">
                  Complete the online registration form with your personal and academic details.
                </p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-secondary text-secondary-foreground rounded-full flex items-center justify-center mx-auto mb-4 text-2xl font-bold">
                  2
                </div>
                <h3 className="text-xl font-semibold mb-2">M-PESA Payment</h3>
                <p className="text-muted-foreground">
                  Enter your M-PESA number and the system automatically deducts the fee.
                </p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-accent text-accent-foreground rounded-full flex items-center justify-center mx-auto mb-4 text-2xl font-bold">
                  3
                </div>
                <h3 className="text-xl font-semibold mb-2">Instant Activation</h3>
                <p className="text-muted-foreground">
                  Receive digital receipt and immediate access to member dashboard.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center text-primary mb-12">
            Membership Benefits
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {benefits.map((benefit, index) => (
              <Card key={index} className="text-center hover:shadow-lg transition-smooth">
                <CardContent className="pt-6">
                  <UserCheck className="w-8 h-8 text-primary mx-auto mb-3" />
                  <p className="text-sm">{benefit}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Requirements */}
      <section className="py-16 bg-muted">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center text-primary mb-12">
            Membership Requirements
          </h2>
          <Card className="max-w-4xl mx-auto">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="w-6 h-6 text-primary" />
                Eligibility Criteria
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3">
                {requirements.map((requirement, index) => (
                  <li key={index} className="flex items-start gap-3">
                    <Badge variant="outline" className="mt-0.5">{index + 1}</Badge>
                    <span className="text-muted-foreground">{requirement}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16">
        <div className="container mx-auto px-4 text-center">
          <div className="max-w-2xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-bold text-primary mb-6">
              Ready to Join?
            </h2>
            <p className="text-muted-foreground mb-8">
              Take the first step towards becoming part of our amazing community. 
              Registration takes less than 5 minutes!
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button variant="hero" size="lg" className="text-lg px-8 py-6">
                Start Registration
              </Button>
              <Button variant="outline" size="lg" className="text-lg px-8 py-6">
                View Constitution
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Note about Backend */}
      <section className="py-8 bg-accent/10">
        <div className="container mx-auto px-4 text-center">
          <p className="text-sm text-muted-foreground">
            <FileText className="w-4 h-4 inline mr-2" />
            Full registration functionality will be available once backend integration is completed.
          </p>
        </div>
      </section>
    </div>
  );
};

export default Membership;